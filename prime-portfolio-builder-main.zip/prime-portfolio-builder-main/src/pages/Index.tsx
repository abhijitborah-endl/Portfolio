
import { Suspense, lazy, useEffect } from "react";
import MainLayout from "@/layouts/MainLayout";

// Lazy load components to improve initial load performance
const Hero = lazy(() => import("@/components/Hero"));
const Projects = lazy(() => import("@/components/Projects"));
const Skills = lazy(() => import("@/components/Skills"));
const Education = lazy(() => import("@/components/Education"));
const Contact = lazy(() => import("@/components/Contact"));

const LoadingFallback = () => (
  <div className="min-h-screen flex items-center justify-center">
    <div className="w-12 h-12 rounded-full border-4 border-primary border-t-transparent animate-spin"></div>
  </div>
);

const Index = () => {
  useEffect(() => {
    // Add page load animations
    document.body.classList.add('animate-fade-in');
    
    // Update page title and metadata
    document.title = "Abhijit Borah | Cybersecurity Engineer";
    
    // Force render of Education section
    const educationSection = document.getElementById('education');
    if (educationSection) {
      educationSection.classList.add('force-visible');
    }
  }, []);

  return (
    <MainLayout>
      <Suspense fallback={<LoadingFallback />}>
        <Hero />
        <Projects />
        <Skills />
        <Education />
        <Contact />
      </Suspense>
    </MainLayout>
  );
};

export default Index;
