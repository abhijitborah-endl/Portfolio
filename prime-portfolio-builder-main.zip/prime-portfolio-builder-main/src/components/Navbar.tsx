
import { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { 
  Menu, 
  X, 
  Github, 
  Linkedin, 
  Mail 
} from "lucide-react";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10;
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [scrolled]);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  const navItems = [
    { label: 'Home', href: '#home' },
    { label: 'Projects', href: '#projects' },
    { label: 'Skills', href: '#skills' },
    { label: 'Education', href: '#education' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <header 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'py-3 glass shadow-sm' : 'py-5 bg-transparent'
      }`}
    >
      <div className="container mx-auto px-4 flex items-center justify-between">
        <a 
          href="#" 
          className="text-xl font-display font-bold text-foreground flex items-center space-x-2"
        >
          <span className="text-primary">&lt;</span>
          <span>Portfolio</span>
          <span className="text-primary">/&gt;</span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          {navItems.map((item) => (
            <a
              key={item.label}
              href={item.href}
              className="text-foreground/80 hover:text-primary transition-colors duration-200 font-medium"
            >
              {item.label}
            </a>
          ))}
        </nav>

        <div className="hidden md:flex items-center space-x-3">
          <Button size="icon" variant="ghost" className="rounded-full">
            <Github className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="ghost" className="rounded-full">
            <Linkedin className="h-5 w-5" />
          </Button>
          <Button size="icon" variant="ghost" className="rounded-full">
            <Mail className="h-5 w-5" />
          </Button>
          <Button className="ml-4 rounded-full">Resume</Button>
        </div>

        {/* Mobile Menu Button */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="md:hidden" 
          onClick={toggleMobileMenu}
        >
          <Menu className="h-6 w-6" />
        </Button>
      </div>

      {/* Mobile Menu */}
      <div
        className={`fixed inset-0 bg-background/95 backdrop-blur-sm z-50 transition-transform duration-300 ease-in-out ${
          mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
        } md:hidden`}
      >
        <div className="container h-full flex flex-col p-8">
          <div className="flex justify-between items-center">
            <a href="#" className="text-xl font-display font-bold">
              <span className="text-primary">&lt;</span>
              <span>Portfolio</span>
              <span className="text-primary">/&gt;</span>
            </a>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleMobileMenu}
            >
              <X className="h-6 w-6" />
            </Button>
          </div>

          <nav className="flex flex-col space-y-6 mt-12">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-foreground text-lg font-medium py-2"
                onClick={toggleMobileMenu}
              >
                {item.label}
              </a>
            ))}
          </nav>

          <div className="mt-auto flex items-center space-x-3 py-6">
            <Button size="icon" variant="outline" className="rounded-full">
              <Github className="h-5 w-5" />
            </Button>
            <Button size="icon" variant="outline" className="rounded-full">
              <Linkedin className="h-5 w-5" />
            </Button>
            <Button size="icon" variant="outline" className="rounded-full">
              <Mail className="h-5 w-5" />
            </Button>
            <Button className="ml-4 rounded-full">Resume</Button>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Navbar;
