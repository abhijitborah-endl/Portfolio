
import { useRef, useEffect } from "react";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import ProjectCard from "./ProjectCard";

const Projects = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('stagger-animate');
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );
    
    if (headingRef.current) {
      observer.observe(headingRef.current);
    }
    
    return () => {
      if (headingRef.current) {
        observer.unobserve(headingRef.current);
      }
    };
  }, []);

  const projects = [
    {
      title: "Keylogger",
      description: "Designed and implemented keylogging functionality using Python, ensuring accurate keystroke capture and efficient data storage. Developed with secure data handling practices for educational and ethical research purposes.",
      image: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["Python", "Data Storage", "Security", "Documentation"],
      githubUrl: "https://github.com",
      period: "November 2023 - May 2024"
    },
    {
      title: "Comprehensive Intrusion Detection System",
      description: "Research paper outlining a comprehensive approach to detecting various types of cyber-attacks while minimizing false positives. By capturing network packets and system activity logs, the method provides crucial forensic evidence for post-incident investigations.",
      image: "https://images.unsplash.com/photo-1558494949-ef010cbdcc31?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["Cyber Forensics", "Network Analysis", "Threat Detection", "Security"],
      githubUrl: "https://github.com",
      period: "December 2024 - January 2025"
    },
    {
      title: "Meteorological Factors Analysis",
      description: "Conducted a project analyzing meteorological factors (temperature, humidity, precipitation) to assess their impact on human comfort levels in Assam, providing insights into local climate conditions.",
      image: "https://images.unsplash.com/photo-1527482797697-8795b05a13fe?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["Data Analysis", "Climate Science", "NCSC", "Research"],
      githubUrl: "https://github.com",
      period: "NCSC 2014"
    },
    {
      title: "Cybersecurity Awareness Program",
      description: "Participated in a Technology Virtual Experience Program focused on Cybersecurity at Delloit. Gained insights into threat analysis, developed a security awareness presentation and gained hands-on experience by working on simulated projects.",
      image: "https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["Cybersecurity", "Threat Analysis", "Delloit", "Presentation"],
      githubUrl: "https://github.com",
      period: "March 2023 - April 2023"
    },
  ];

  return (
    <section id="projects" className="py-24 relative">
      <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-accent/30 rounded-full blur-3xl -z-10" />
      
      <div className="container mx-auto px-4">
        <div ref={headingRef} className="max-w-2xl mx-auto text-center mb-16">
          <div className="title-chip mb-4">Projects</div>
          <h2 className="heading-2 mb-4">Cybersecurity portfolio</h2>
          <p className="text-lg text-muted-foreground">
            A collection of projects that demonstrate my skills in cybersecurity,
            network analysis, and building secure systems to combat modern cyber threats.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {projects.map((project, index) => (
            <ProjectCard
              key={index}
              index={index}
              title={project.title}
              description={project.description}
              image={project.image}
              tags={project.tags}
              githubUrl={project.githubUrl}
              liveUrl={project.period}
            />
          ))}
        </div>

        <div className="flex justify-center mt-12">
          <Button 
            size="lg" 
            variant="outline" 
            className="rounded-full gap-2 group"
          >
            View All Projects
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Projects;
