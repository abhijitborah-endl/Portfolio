
import { useRef, useEffect } from "react";
import { Code, Server, Database, Shield, Terminal, Laptop } from "lucide-react";
import SkillCard from "./SkillCard";

const Skills = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('stagger-animate');
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );
    
    if (headingRef.current) {
      observer.observe(headingRef.current);
    }
    
    return () => {
      if (headingRef.current) {
        observer.unobserve(headingRef.current);
      }
    };
  }, []);

  const skillCategories = [
    {
      icon: <Code className="h-6 w-6 text-primary" />,
      title: "Programming Languages",
      skills: ["Python", "JavaScript", "C/C++", "HTML/CSS", "SQL (Oracle)", "Bash"]
    },
    {
      icon: <Shield className="h-6 w-6 text-primary" />,
      title: "Cybersecurity",
      skills: ["NIST", "ISO 27001", "MITRE ATT&CK", "OWASP Top 10", "Static & Dynamic Analysis"]
    },
    {
      icon: <Server className="h-6 w-6 text-primary" />,
      title: "Cloud Security",
      skills: ["AWS Security", "Azure Security", "Google Cloud Security", "VPNs"]
    },
    {
      icon: <Database className="h-6 w-6 text-primary" />,
      title: "Tools & Infrastructure",
      skills: ["MongoDB", "Node.js", "Git & GitHub", "PowerShell"]
    },
    {
      icon: <Terminal className="h-6 w-6 text-primary" />,
      title: "Security Tools",
      skills: ["SIEM", "Metasploit", "Nmap", "Burp Suite", "Nessus", "Wireshark", "Snort"]
    },
    {
      icon: <Laptop className="h-6 w-6 text-primary" />,
      title: "Forensics & Analysis",
      skills: ["Incident Response", "Log Analysis", "Network Packet Analysis", "Malware Analysis"]
    }
  ];

  return (
    <section id="skills" className="py-24 bg-secondary/50">
      <div className="container mx-auto px-4">
        <div ref={headingRef} className="max-w-2xl mx-auto text-center mb-16">
          <div className="title-chip mb-4">Skills</div>
          <h2 className="heading-2 mb-4">Cybersecurity expertise</h2>
          <p className="text-lg text-muted-foreground">
            A comprehensive set of technical skills acquired through academic studies,
            certifications, and hands-on cybersecurity projects.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <SkillCard
              key={index}
              icon={category.icon}
              title={category.title}
              skills={category.skills}
              index={index}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;
