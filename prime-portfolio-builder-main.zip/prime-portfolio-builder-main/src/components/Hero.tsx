
import { Button } from "@/components/ui/button";
import { ArrowRight, Github, Shield, Terminal } from "lucide-react";
import { useEffect, useRef } from "react";

const Hero = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('stagger-animate');
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );
    
    if (containerRef.current) {
      observer.observe(containerRef.current);
    }
    
    return () => {
      if (containerRef.current) {
        observer.unobserve(containerRef.current);
      }
    };
  }, []);

  return (
    <section 
      id="home" 
      className="min-h-screen pt-24 flex flex-col justify-center relative overflow-hidden"
    >
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-accent/40 rounded-full blur-3xl" />
      
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center gap-12 z-10">
        <div ref={containerRef} className="w-full md:w-1/2 space-y-6">
          <div className="title-chip">Cybersecurity Specialist</div>
          <h1 className="heading-1">
            <span className="text-primary">Abhijit Borah</span> - Securing Digital Frontiers
          </h1>
          <p className="text-lg text-muted-foreground md:pr-12">
            Final-year Computer Science engineering student specializing in Cybersecurity. 
            Passionate about ethical hacking, network security, malware analysis and building 
            secure systems to combat modern cyber threats.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Button size="lg" className="rounded-full gap-2 group">
              View Projects
              <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button 
              size="lg" 
              variant="outline" 
              className="rounded-full gap-2" 
              asChild
            >
              <a href="https://www.linkedin.com/in/abhijit-borah-143300239" target="_blank" rel="noopener noreferrer">
                <Github className="h-4 w-4" />
                LinkedIn Profile
              </a>
            </Button>
          </div>
          
          <div className="flex items-center gap-6 pt-8">
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Specializing in</div>
                <div className="font-medium">Cybersecurity</div>
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center">
                <Terminal className="h-6 w-6 text-primary" />
              </div>
              <div>
                <div className="text-sm text-muted-foreground">Experienced with</div>
                <div className="font-medium">Python, SIEM, Cloud</div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="w-full md:w-1/2 flex justify-center md:justify-end">
          <div className="relative w-full max-w-md aspect-square">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-accent/30 rounded-2xl transform rotate-6 scale-95" />
            <div className="absolute inset-0 glass rounded-2xl shadow-lg transform -rotate-3" />
            <div className="absolute inset-0 flex items-center justify-center">
              <img 
                src="public/lovable-uploads/b9e1aff8-ebc7-442e-a14c-db2f0a1edcea.png" 
                alt="Abhijit Borah Profile"
                className="w-4/5 h-4/5 object-cover rounded-xl shadow-md animate-fade-in" 
              />
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2 flex items-center justify-center">
        <div className="w-6 h-10 border-2 border-foreground/30 rounded-full flex items-start justify-center p-1">
          <div className="w-1.5 h-1.5 bg-foreground/50 rounded-full animate-bounce" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
