
import { useRef, useEffect } from "react";
import { 
  GraduationCap, 
  Award, 
  BookOpen,
  Calendar
} from "lucide-react";

const Education = () => {
  const headingRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    const observers = [headingRef, timelineRef].map(ref => 
      new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('stagger-animate');
            observers.forEach(obs => obs.unobserve(entry.target));
          }
        },
        { threshold: 0.1, rootMargin: "0px 0px -10% 0px" }
      )
    );
    
    if (headingRef.current) {
      observers[0].observe(headingRef.current);
    }
    
    if (timelineRef.current) {
      observers[1].observe(timelineRef.current);
    }
    
    // Make sure the education section is visible initially
    setTimeout(() => {
      if (timelineRef.current && !timelineRef.current.classList.contains('stagger-animate')) {
        timelineRef.current.classList.add('stagger-animate');
      }
    }, 500);
    
    return () => {
      if (headingRef.current) observers[0].unobserve(headingRef.current);
      if (timelineRef.current) observers[1].unobserve(timelineRef.current);
    };
  }, []);

  const education = [
    {
      degree: "B.Tech Computer Science and Engineering",
      institution: "Lovely Professional University",
      period: "2022 - 2025",
      description: "Specializing in Cybersecurity. Final year student with a focus on ethical hacking, network security, and malware analysis.",
      courses: ["Cybersecurity", "Network Security", "Malware Analysis", "System Design"],
      location: "Jalandhar, Punjab"
    },
    {
      degree: "Diploma in Computer Science and Engineering",
      institution: "Lovely Professional University",
      period: "2018 - 2021",
      description: "Fundamental computer science education with focus on programming and system security.",
      courses: ["Programming Fundamentals", "Computer Architecture", "Database Systems", "Web Development"],
      location: "Jalandhar, Punjab"
    }
  ];

  const certifications = [
    {
      title: "Certified in Cyber Security (CC Certification)",
      issuer: "ISC2",
      date: "November 2024 - January 2025",
      details: [
        "Implementing and managing access controls to protect systems and data.",
        "Understanding encryption, decryption, and key management techniques.",
        "Implementing and analyzing logs to detect and investigate security threats."
      ]
    },
    {
      title: "Technology Virtual Experience Program (Cyber Security)",
      issuer: "Delloit",
      date: "March 2023 - April 2023",
      details: [
        "Gained insights into threat analysis",
        "Developed a security awareness presentation",
        "Hands-on experience with simulated projects"
      ]
    },
    {
      title: "Work Experience: Ghost Writer",
      issuer: "GoForMeet",
      date: "Present",
      details: [
        "Creating articles, blogs and more",
        "Adapting to different tones and styles",
        "Conducting research and refining content for clarity and impact"
      ]
    }
  ];

  return (
    <section id="education" className="py-24 relative">
      <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-primary/10 rounded-full blur-3xl -z-10" />
      
      <div className="container mx-auto px-4">
        <div ref={headingRef} className="max-w-2xl mx-auto text-center mb-16">
          <div className="title-chip mb-4">Education</div>
          <h2 className="heading-2 mb-4">Academic background</h2>
          <p className="text-lg text-muted-foreground">
            My educational journey and professional certifications that have shaped
            my understanding of cybersecurity and computer science.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h3 className="text-2xl font-semibold mb-8 flex items-center gap-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              Formal Education
            </h3>
            
            <div 
              ref={timelineRef} 
              className="space-y-12 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-1/2 before:h-full before:w-0.5 before:bg-border"
            >
              {education.map((item, index) => (
                <div key={index} className="relative pl-12">
                  <div className="absolute left-0 top-1 w-10 h-10 rounded-full bg-secondary flex items-center justify-center">
                    <BookOpen className="h-5 w-5 text-primary" />
                  </div>
                  
                  <div className="glass p-6 rounded-lg border border-border">
                    <div className="flex flex-wrap justify-between items-start gap-2 mb-3">
                      <h4 className="text-xl font-semibold">{item.degree}</h4>
                      <div className="flex items-center text-sm text-muted-foreground bg-secondary px-3 py-1 rounded-full">
                        <Calendar className="h-3.5 w-3.5 mr-1" />
                        {item.period}
                      </div>
                    </div>
                    
                    <p className="text-base font-medium text-foreground/80 mb-2">
                      {item.institution}, {item.location}
                    </p>
                    
                    <p className="text-muted-foreground mb-4">
                      {item.description}
                    </p>
                    
                    <div className="mb-2">
                      <h5 className="text-sm font-semibold mb-2">Key Courses:</h5>
                      <div className="flex flex-wrap gap-2">
                        {item.courses.map((course, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 text-xs font-medium bg-secondary text-secondary-foreground rounded-full"
                          >
                            {course}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h3 className="text-2xl font-semibold mb-8 flex items-center gap-2">
              <Award className="h-6 w-6 text-primary" />
              Certifications & Experience
            </h3>
            
            <div className="space-y-6">
              {certifications.map((cert, index) => (
                <div
                  key={index}
                  className="p-5 border border-border rounded-lg hover:border-primary/20 transition-colors duration-300"
                >
                  <div className="flex justify-between items-center mb-3">
                    <h4 className="font-semibold">{cert.title}</h4>
                    <span className="text-sm text-muted-foreground">{cert.date}</span>
                  </div>
                  <p className="text-sm text-muted-foreground mb-3">{cert.issuer}</p>
                  <ul className="space-y-2">
                    {cert.details.map((detail, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2" />
                        <span className="text-muted-foreground">{detail}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
            
            <div className="mt-8 p-6 bg-primary/5 rounded-lg border border-primary/10">
              <h4 className="text-lg font-semibold mb-3">Contact Information</h4>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2" />
                  <div>
                    <span className="font-medium">LinkedIn:</span>
                    <a href="https://www.linkedin.com/in/abhijit-borah-143300239" target="_blank" rel="noopener noreferrer" className="text-primary ml-1 hover:underline">
                      abhijit-borah-143300239
                    </a>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2" />
                  <div>
                    <span className="font-medium">Phone:</span>
                    <span className="text-muted-foreground ml-1">8638108844</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2" />
                  <div>
                    <span className="font-medium">Email:</span>
                    <a href="mailto:borahabhijit84@gmail.com" className="text-primary ml-1 hover:underline">
                      borahabhijit84@gmail.com
                    </a>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;
